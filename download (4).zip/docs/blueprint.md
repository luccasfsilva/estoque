# **App Name**: EstoqueVision

## Core Features:

- Inventory Display: Display the inventory in a tabular format with columns for Code, Name, Quantity, Output, Quantity After Output, Date (formatted as dd/mm/yyyy), and Sector.
- Row Actions: Provide 'Edit' and 'Remove' buttons in each row of the inventory table to allow easy modification and deletion of items.
- User Profile Management: Include a user profile menu with options to update password and logout, ensuring secure session management.
- Modern UI Design: Implement a visually appealing and modern design to enhance user experience.

## Style Guidelines:

- Primary color: Deep Blue (#3F51B5) to provide a sense of trust and stability.
- Background color: Light Gray (#F0F2F5) to ensure content stands out and readability is enhanced.
- Accent color: Teal (#009688) for interactive elements to draw user attention.
- Body and headline font: 'Inter' sans-serif font for a clean, modern, objective look. It's suitable for both headlines and body text
- Use simple, outlined icons from a library like FontAwesome for actions and navigation.
- Ensure a responsive layout that adapts to different screen sizes for optimal viewing on desktops, tablets, and mobile devices.
- Use subtle transitions and animations to provide feedback on user interactions, such as adding or removing items.