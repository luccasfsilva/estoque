export interface InventoryItem {
  id: string;
  codigo: string;
  nome: string;
  quantidade: number;
  saida: number;
  quantidadeAposSaida: number;
  data: string; // Store as YYYY-MM-DD string
  setor: string;
}
