
"use client";

const TOKEN_KEY = "access_token_estq_vision";
const USERNAME_KEY = "username_estq_vision";

export const getToken = (): string | null => {
  if (typeof window !== "undefined") {
    return localStorage.getItem(TOKEN_KEY);
  }
  return null;
};

export const setToken = (token: string): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem(TOKEN_KEY, token);
  }
};

export const removeToken = (): void => {
  if (typeof window !== "undefined") {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(USERNAME_KEY); // Also remove username on logout
  }
};

export const setUsername = (username: string): void => {
  if (typeof window !== "undefined") {
    localStorage.setItem(USERNAME_KEY, username);
  }
};

export const getUsername = (): string | null => {
  if (typeof window !== "undefined") {
    return localStorage.getItem(USERNAME_KEY);
  }
  return null;
};

// The parseJwt and isTokenExpired functions from the original code
// are complex and might not be perfectly safe or standard.
// For a real application, use a proper JWT library (e.g., jwt-decode on client, jose on server).
// For this mock, we'll assume token presence means authenticated and it doesn't expire quickly.
export const isAuthenticated = (): boolean => {
  if (typeof window !== "undefined") {
    const token = getToken();
    // Basic check: if token exists. Real app would validate and check expiry.
    return !!token;
  }
  return false;
};
