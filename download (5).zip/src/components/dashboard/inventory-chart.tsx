"use client";

import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Tooltip as RechartsTooltip } from "recharts";
import {
  ChartConfig,
  ChartContainer,
  ChartTooltipContent,
} from "@/components/ui/chart";
import type { InventoryItem } from "@/lib/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

interface InventoryChartProps {
  data: InventoryItem[];
}

const chartConfig = {
  quantidadeAposSaida: {
    label: "Qtde. em Estoque",
    color: "hsl(var(--primary))",
  },
} satisfies ChartConfig;

export function InventoryChart({ data }: InventoryChartProps) {
  if (data.length === 0) {
    return (
      <Card className="shadow-lg">
        <CardHeader>
          <CardTitle>Dashboard de Estoque</CardTitle>
          <CardDescription>Visão geral das quantidades de itens.</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground py-8">Nenhum dado para exibir no gráfico.</p>
        </CardContent>
      </Card>
    )
  }

  const chartData = data.map(item => ({
    name: item.nome,
    quantidadeAposSaida: item.quantidadeAposSaida,
  }));

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="font-headline text-2xl">Dashboard de Estoque</CardTitle>
        <CardDescription>Visão geral das quantidades de itens em estoque.</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[400px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 5, right: 20, left: -20, bottom: 50 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} />
              <XAxis 
                dataKey="name" 
                tickLine={false} 
                axisLine={false} 
                tickMargin={8} 
                angle={-45}
                textAnchor="end"
                height={70}
                interval={0}
                tickFormatter={(value) => value.length > 15 ? `${value.substring(0,12)}...` : value}
              />
              <YAxis 
                tickLine={false} 
                axisLine={false} 
                tickMargin={8}
                allowDecimals={false}
              />
              <RechartsTooltip
                cursor={{ fill: "hsl(var(--muted))" }}
                content={<ChartTooltipContent hideLabel />}
              />
              <Bar dataKey="quantidadeAposSaida" fill="var(--color-quantidadeAposSaida)" radius={4} />
            </BarChart>
          </ResponsiveContainer>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
