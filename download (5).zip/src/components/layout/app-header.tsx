"use client";

import Link from "next/link";
import { UserProfileMenu } from "./user-profile-menu";
import { Building2 } from "lucide-react";

export function AppHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card shadow-sm">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <Building2 className="h-7 w-7 text-primary" />
          <h1 className="font-headline text-2xl font-semibold text-foreground">
            EstoqueVision
          </h1>
        </Link>
        <UserProfileMenu />
      </div>
    </header>
  );
}
