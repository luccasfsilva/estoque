
"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { removeToken, getUsername } from "@/lib/auth-helpers";
import { useToast } from "@/hooks/use-toast";
import { LogOut, UserCircle, LockKeyhole } from "lucide-react";

export function UserProfileMenu() {
  const router = useRouter();
  const { toast } = useToast();
  const [displayName, setDisplayName] = useState("Usuário");
  const [displayEmail, setDisplayEmail] = useState("usuario@example.com");

  useEffect(() => {
    const storedUsername = getUsername();
    if (storedUsername) {
      setDisplayName(storedUsername);
      // You could create a mock email or leave it as is
      // setDisplayEmail(`${storedUsername.toLowerCase()}@example.com`);
    }
  }, []);

  const handleLogout = () => {
    removeToken(); // This will also remove the username
    toast({ title: "Logout bem-sucedido!" });
    router.push("/login");
  };

  const handleUpdatePassword = () => {
    toast({
      title: "Funcionalidade Indisponível",
      description: "A atualização de senha ainda não foi implementada.",
      variant: "default"
    });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 w-10 rounded-full">
          <Avatar className="h-10 w-10">
            <AvatarImage src="https://placehold.co/100x100.png" alt="User Avatar" data-ai-hint="user avatar" />
            <AvatarFallback>
              <UserCircle size={24} />
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{displayName}</p>
            <p className="text-xs leading-none text-muted-foreground">
              {displayEmail}
            </p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleUpdatePassword} className="cursor-pointer">
          <LockKeyhole className="mr-2 h-4 w-4" />
          <span>Atualizar Senha</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-destructive focus:text-destructive focus:bg-destructive/10">
          <LogOut className="mr-2 h-4 w-4" />
          <span>Sair</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
