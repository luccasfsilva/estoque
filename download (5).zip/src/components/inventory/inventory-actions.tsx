"use client";

import { Button } from "@/components/ui/button";
import { PlusCircle, Eye, BarChartBig } from "lucide-react";

interface InventoryActionsProps {
  onAddItem: () => void;
  onToggleDashboard: () => void;
  isDashboardVisible: boolean;
}

export function InventoryActions({ onAddItem, onToggleDashboard, isDashboardVisible }: InventoryActionsProps) {
  return (
    <div className="my-6 flex flex-wrap justify-center gap-3 px-4">
      <Button onClick={onAddItem} className="shadow-md">
        <PlusCircle className="mr-2 h-5 w-5" />
        Adicionar Item
      </Button>
      <Button onClick={onToggleDashboard} variant="outline" className="shadow-md">
        {isDashboardVisible ? <Eye className="mr-2 h-5 w-5" /> : <BarChartBig className="mr-2 h-5 w-5" />}
        {isDashboardVisible ? "Ocultar Dashboard" : "Visualizar Estoque"}
      </Button>
    </div>
  );
}
