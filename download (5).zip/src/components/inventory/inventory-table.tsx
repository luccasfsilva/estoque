"use client";

import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow, TableCaption } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import type { InventoryItem } from "@/lib/types";
import { Pencil, Trash2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";


interface InventoryTableProps {
  items: InventoryItem[];
  onEdit: (item: InventoryItem) => void;
  onRemove: (item: InventoryItem) => void;
}

export function InventoryTable({ items, onEdit, onRemove }: InventoryTableProps) {
  if (items.length === 0) {
    return <p className="my-6 text-center text-muted-foreground">Nenhum item no estoque.</p>;
  }

  return (
    <ScrollArea className="whitespace-nowrap rounded-md border shadow-md">
      <Table>
        <TableCaption>Lista de itens atualmente em estoque.</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead className="font-semibold">Código</TableHead>
            <TableHead className="font-semibold">Nome</TableHead>
            <TableHead className="text-right font-semibold">Quantidade</TableHead>
            <TableHead className="text-right font-semibold">Saída</TableHead>
            <TableHead className="text-right font-semibold">Após Saída</TableHead>
            <TableHead className="font-semibold">Data</TableHead>
            <TableHead className="font-semibold">Setor</TableHead>
            <TableHead className="text-center font-semibold">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => (
            <TableRow key={item.id}>
              <TableCell>
                <Badge variant="secondary">{item.codigo}</Badge>
              </TableCell>
              <TableCell className="font-medium">{item.nome}</TableCell>
              <TableCell className="text-right">{item.quantidade}</TableCell>
              <TableCell className="text-right text-orange-600">{item.saida}</TableCell>
              <TableCell className="text-right font-bold text-primary">{item.quantidadeAposSaida}</TableCell>
              <TableCell>{format(new Date(item.data), "dd/MM/yyyy", { locale: ptBR })}</TableCell>
              <TableCell>{item.setor}</TableCell>
              <TableCell className="text-center">
                <div className="flex justify-center gap-2">
                  <Button variant="outline" size="icon" onClick={() => onEdit(item)} className="h-8 w-8 hover:text-primary">
                    <Pencil className="h-4 w-4" />
                    <span className="sr-only">Editar</span>
                  </Button>
                  <Button variant="outline" size="icon" onClick={() => onRemove(item)} className="h-8 w-8 hover:text-destructive">
                    <Trash2 className="h-4 w-4" />
                    <span className="sr-only">Remover</span>
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );
}
