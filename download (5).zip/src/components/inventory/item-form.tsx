"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";
import type { InventoryItem } from "@/lib/types";

const formSchema = z.object({
  codigo: z.string().min(1, "Código é obrigatório."),
  nome: z.string().min(1, "Nome é obrigatório."),
  quantidade: z.coerce.number().min(0, "Quantidade deve ser positiva."),
  saida: z.coerce.number().min(0, "Saída deve ser positiva."),
  data: z.date({ required_error: "Data é obrigatória." }),
  setor: z.string().min(1, "Setor é obrigatório."),
}).refine(data => data.quantidade >= data.saida, {
  message: "Saída não pode ser maior que a quantidade.",
  path: ["saida"],
});

type ItemFormValues = z.infer<typeof formSchema>;

interface ItemFormProps {
  onSubmit: (values: InventoryItem) => void;
  initialData?: InventoryItem | null;
  onClose: () => void;
}

export function ItemForm({ onSubmit, initialData, onClose }: ItemFormProps) {
  const form = useForm<ItemFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: initialData
      ? {
          ...initialData,
          quantidade: Number(initialData.quantidade),
          saida: Number(initialData.saida),
          data: new Date(initialData.data),
        }
      : {
          codigo: "",
          nome: "",
          quantidade: 0,
          saida: 0,
          data: new Date(),
          setor: "",
        },
  });

  const handleSubmit = (values: ItemFormValues) => {
    const quantidadeAposSaida = values.quantidade - values.saida;
    onSubmit({
      ...values,
      id: initialData?.id || crypto.randomUUID(),
      data: format(values.data, "yyyy-MM-dd"), // Store date as YYYY-MM-DD
      quantidadeAposSaida,
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <FormField
            control={form.control}
            name="codigo"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Código</FormLabel>
                <FormControl>
                  <Input placeholder="Ex: PROD001" {...field} disabled={!!initialData} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="nome"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Nome do Item</FormLabel>
                <FormControl>
                  <Input placeholder="Ex: Teclado Mecânico" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <FormField
            control={form.control}
            name="quantidade"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Quantidade</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="0" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="saida"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Saída</FormLabel>
                <FormControl>
                  <Input type="number" placeholder="0" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <FormField
            control={form.control}
            name="data"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Data</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP", { locale: ptBR })
                        ) : (
                          <span>Escolha uma data</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      disabled={(date) =>
                        date > new Date() || date < new Date("1900-01-01")
                      }
                      initialFocus
                      locale={ptBR}
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="setor"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Setor</FormLabel>
                <FormControl>
                  <Input placeholder="Ex: TI, Marketing" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="flex justify-end gap-2 pt-4">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button type="submit">{initialData ? "Atualizar Item" : "Adicionar Item"}</Button>
        </div>
      </form>
    </Form>
  );
}
