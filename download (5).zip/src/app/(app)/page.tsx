
"use client";

import { useState, useEffect } from "react";
import { InventoryActions } from "@/components/inventory/inventory-actions";
import { InventoryTable } from "@/components/inventory/inventory-table";
import { InventoryChart } from "@/components/dashboard/inventory-chart";
import { ItemForm } from "@/components/inventory/item-form";
import type { InventoryItem } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const initialInventoryData: InventoryItem[] = [
  { id: '1', codigo: "001", nome: "Teclado Gamer RGB", quantidade: 20, saida: 5, quantidadeAposSaida: 15, data: "2024-04-10", setor: "TI" },
  { id: '2', codigo: "002", nome: "Mouse Sem Fio Ergonômico", quantidade: 30, saida: 10, quantidadeAposSaida: 20, data: "2024-04-12", setor: "TI" },
  { id: '3', codigo: "003", nome: "Monitor LED 24 polegadas", quantidade: 15, saida: 2, quantidadeAposSaida: 13, data: "2024-05-01", setor: "Hardware" },
  { id: '4', codigo: "004", nome: "Cadeira de Escritório Premium", quantidade: 10, saida: 1, quantidadeAposSaida: 9, data: "2024-05-15", setor: "Mobiliário" },
];

const sortInventoryByName = (items: InventoryItem[]): InventoryItem[] => {
  return [...items].sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR', { sensitivity: 'base' }));
};

export default function InventoryPage() {
  const { toast } = useToast();
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [showDashboard, setShowDashboard] = useState(false);
  const [isItemFormOpen, setIsItemFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
  const [itemToRemove, setItemToRemove] = useState<InventoryItem | null>(null);

  // Load initial data on mount (simulating API fetch)
   useEffect(() => {
    // Simulate fetching data or loading from local storage
    const storedInventory = localStorage.getItem("inventoryDataEstoqueVision");
    let dataToLoad: InventoryItem[];
    if (storedInventory) {
      dataToLoad = JSON.parse(storedInventory);
    } else {
      dataToLoad = initialInventoryData;
    }
    setInventory(sortInventoryByName(dataToLoad));
  }, []);

  // Save to local storage whenever inventory changes
  useEffect(() => {
    if(inventory.length > 0) { // Avoid saving empty array on initial load if data is not ready
        localStorage.setItem("inventoryDataEstoqueVision", JSON.stringify(inventory));
    }
  }, [inventory]);


  const handleAddItem = (item: InventoryItem) => {
    // Check for duplicate codigo
    if (inventory.some(i => i.codigo === item.codigo)) {
      toast({
        title: "Erro ao Adicionar",
        description: `Item com código ${item.codigo} já existe.`,
        variant: "destructive",
      });
      return;
    }
    setInventory((prev) => sortInventoryByName([...prev, item]));
    toast({ title: "Sucesso!", description: `Item "${item.nome}" adicionado.` });
    setIsItemFormOpen(false);
  };

  const handleUpdateItem = (item: InventoryItem) => {
    setInventory((prev) =>
      sortInventoryByName(prev.map((i) => (i.id === item.id ? item : i)))
    );
    toast({ title: "Sucesso!", description: `Item "${item.nome}" atualizado.` });
    setIsItemFormOpen(false);
    setEditingItem(null);
  };

  const handleRemoveItem = () => {
    if (!itemToRemove) return;
    setInventory((prev) => prev.filter((i) => i.id !== itemToRemove.id)); // Sorting is maintained
    toast({ title: "Sucesso!", description: `Item "${itemToRemove.nome}" removido.` });
    setItemToRemove(null);
  };

  const openAddItemModal = () => {
    setEditingItem(null);
    setIsItemFormOpen(true);
  };

  const openEditItemModal = (item: InventoryItem) => {
    setEditingItem(item);
    setIsItemFormOpen(true);
  };

  const openRemoveConfirmation = (item: InventoryItem) => {
    setItemToRemove(item);
  };

  return (
    <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
      <InventoryActions
        onAddItem={openAddItemModal}
        onToggleDashboard={() => setShowDashboard(!showDashboard)}
        isDashboardVisible={showDashboard}
      />

      {showDashboard && (
        <div className="mb-8">
          <InventoryChart data={inventory} />
        </div>
      )}

      <div className="mt-8">
        <h2 className="mb-6 text-center font-headline text-3xl font-semibold text-foreground">
          Itens no Estoque
        </h2>
        <InventoryTable
          items={inventory}
          onEdit={openEditItemModal}
          onRemove={openRemoveConfirmation}
        />
      </div>

      <Dialog open={isItemFormOpen} onOpenChange={(open) => {
        setIsItemFormOpen(open);
        if (!open) setEditingItem(null);
      }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle className="font-headline text-2xl">
              {editingItem ? "Atualizar Item" : "Adicionar Novo Item"}
            </DialogTitle>
            <DialogDescription>
              {editingItem
                ? "Modifique os detalhes do item existente."
                : "Preencha os detalhes do novo item para adicioná-lo ao estoque."}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <ItemForm
              onSubmit={editingItem ? handleUpdateItem : handleAddItem}
              initialData={editingItem}
              onClose={() => {
                setIsItemFormOpen(false);
                setEditingItem(null);
              }}
            />
          </div>
        </DialogContent>
      </Dialog>

      {itemToRemove && (
        <AlertDialog open={!!itemToRemove} onOpenChange={(open) => !open && setItemToRemove(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Confirmar Remoção</AlertDialogTitle>
              <AlertDialogDescription>
                Tem certeza que deseja remover o item "{itemToRemove.nome}" (Código: {itemToRemove.codigo})? Esta ação não pode ser desfeita.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel onClick={() => setItemToRemove(null)}>Cancelar</AlertDialogCancel>
              <AlertDialogAction onClick={handleRemoveItem} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                Remover
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}
    </div>
  );
}
