(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_login_page_tsx_801c1381._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_login_page_tsx_801c1381._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d0bb04ca._.js",
    "static/chunks/_860b558d._.js"
  ],
  "source": "dynamic"
});
