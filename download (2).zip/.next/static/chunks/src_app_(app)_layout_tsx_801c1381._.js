(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(app)_layout_tsx_801c1381._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(app)_layout_tsx_801c1381._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0c4d2413._.js",
    "static/chunks/node_modules_516ba031._.js",
    "static/chunks/src_b0fbc712._.js"
  ],
  "source": "dynamic"
});
