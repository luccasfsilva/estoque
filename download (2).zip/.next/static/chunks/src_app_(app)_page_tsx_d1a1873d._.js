(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(app)_page_tsx_d1a1873d._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(app)_page_tsx_d1a1873d._.js",
  "chunks": [
    "static/chunks/src_afa7e3df._.js",
    "static/chunks/node_modules_date-fns_b4be2ddb._.js",
    "static/chunks/node_modules_lodash_f240f67a._.js",
    "static/chunks/node_modules_recharts_es6_8235043b._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_ee760afb._.js",
    "static/chunks/node_modules_react-day-picker_dist_index_esm_9fc30424.js",
    "static/chunks/node_modules_2bf18822._.js"
  ],
  "source": "dynamic"
});
